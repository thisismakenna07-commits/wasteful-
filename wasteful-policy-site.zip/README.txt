WASTEFUL POLICY SITE

Files:
- index.html
- terms.html
- privacy.html

BEFORE PUBLISHING:
1. Replace [YOUR LEGAL/OWNER NAME].
2. Replace [YOUR SUPPORT EMAIL OR SUPPORT SERVER LINK].
3. Make sure the privacy policy matches what your actual bot collects/stores.
4. Publish the folder at a public HTTPS URL.

Discord Developer Portal:
Terms of Service URL:
https://YOUR-DOMAIN/terms.html

Privacy Policy URL:
https://YOUR-DOMAIN/privacy.html

This is a general template, not legal advice.
